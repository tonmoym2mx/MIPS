package com.tonmoy.gakk.meow.mips.data

fun main(){
    
}

class Add(rs: Register, rt: Register,rd: Register): TypeR(rs, rt, rd, 0,32)
class Addu(rs: Register, rt: Register,rd: Register): TypeR(rs, rt, rd, 0,33)
class And(rs: Register, rt: Register,rd: Register): TypeR(rs, rt, rd, 0,36)
class Xor(rs: Register, rt: Register,rd: Register): TypeR(rs, rt, rd, 0,38)
class Or(rs: Register, rt: Register,rd: Register): TypeR(rs, rt, rd, 0,37)
class Nor(rs: Register, rt: Register,rd: Register): TypeR(rs, rt, rd, 0,39)
interface Instruction{
    val opcode:Int
    val opcodeBits: Int
        get() = 6
    val rsBits: Int
        get() = 5
    val rtBits: Int
        get() = 5
    fun instructionFormat():String
    fun decimalInstruction():String
    fun binaryInstruction():String

}


open class TypeR(

    var rs:Register,
    var rt:Register,
    var rd:Register,
    var shamt:Int,
    var functionCode:Int
): Instruction {
    override val opcode:Int = 0
    val  rdBits:Int = 5
    val  functionCodeBits:Int = 6
    val  shamtBits:Int = 5


    /*add t0 t1 t2
    rs, rt, rd,
    Binary: 00000001001010100100000000100000
    Hex: 0x012A4020
    31	26	25	21	20	16	15	11	10	6	5	0
    SPECIAL	t1	t2	t0	0	ADD
    000000	01001	01010	01000	00000	100000
    */

    override fun binaryInstruction(): String {
       return "${opcode.toBinary(opcodeBits)} ${rt.toBinary()} ${rd.toBinary()} ${rs.toBinary()} ${shamt.toBinary(shamtBits)} ${functionCode.toBinary(functionCodeBits)}"

    }
    override fun decimalInstruction(): String {
        return "$opcode $rt $rd $rs $shamt $functionCode"

    }

    override fun instructionFormat():String {
        return  "R Type [opcode:$opcodeBits bits, rs:$rsBits bits, rt:$rtBits Bits, rd:$rdBits Bits, shamt:$shamtBits bits, functionCode:$functionCodeBits bits]"
    }


}
class TypeI(
    var rs:Register,
    var rt:Register,
    var immediate:Int
): Instruction {
    override var opcode:Int = 8
    val immediateBits:Int = 16
    override fun instructionFormat():String {
        return  "I(opcode:$opcodeBits bits, rs:$rsBits bits, rt:$rtBits, immediate:$immediateBits bits)"
    }

    override fun decimalInstruction(): String {
        TODO("Not yet implemented")
    }

    override fun binaryInstruction(): String {
        TODO("Not yet implemented")
    }


}

class TypeJ(
    var address:Int
): Instruction {
    override var opcode:Int = 2
    val addressBits:Int = 26
    override fun instructionFormat():String {
        return  "I(opcode:$opcodeBits bits ,address:${addressBits} bits )"
    }

    override fun decimalInstruction(): String {
        TODO("Not yet implemented")
    }

    override fun binaryInstruction(): String {
        TODO("Not yet implemented")
    }
}

enum class Register(val number:Int?=null,var value:Int?=null){
    ZERO(0),
    AT(1),
    V0(2),
    V1(3),
    A0(4),
    A1(5),
    A2(6),
    A3(7),
    T0(8),
    T1(9),
    T2(10),
    T3(11),
    T4(12),
    T5(13),
    T6(14),
    T7(15),
    S0(16),
    S1(17),
    S2(18),
    S3(19),
    S4(20),
    S5(21),
    S6(22),
    S7(23),
    T8(24),
    T9(25),
    K0(26),
    K1(27),
    GP(28),
    SP(29),
    FP(30),
    RA(31),
    PC(),
    HI(),
    LO();
    fun toBinary() = number?.toBinary(5)

}
fun Int.toBinary(len: Int): String {
    return String.format(
        "%" + len + "s",
        this.toString(2)
    ).replace(" ".toRegex(), "0")
}